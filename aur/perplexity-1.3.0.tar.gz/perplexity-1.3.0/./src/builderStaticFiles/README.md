This directory is copied as is into each new application. The `.plist` file is like a Mac config file for the app executable. It can contain settings for permissions, etc.
